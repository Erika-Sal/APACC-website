const box1 = document.querySelector(".s11");
const box1Text = document.querySelector(".s11text");
const box2 = document.querySelector(".s12");
const box2Text = document.querySelector(".s12text");
const box3 = document.querySelector(".s13");
const box3Text = document.querySelector(".s13text");
const box4 = document.querySelector(".s21");
const box4Text = document.querySelector(".s21text")
const box5 = document.querySelector(".s22");
const box5Text = document.querySelector(".s22text")
const box6 = document.querySelector(".s23");
const box6Text = document.querySelector(".s23text")
const box7 = document.querySelector(".s31");
const box7Text = document.querySelector(".s31text")
const box8 = document.querySelector(".s32");
const box8Text = document.querySelector(".s32text")
const box9 = document.querySelector(".s33");
const box9Text = document.querySelector(".s33text")
const winner = document.querySelector(".winner");

let player1 = true; 
let cells = [["j", "j", "j"], ["j", "j", "j"],["j", "j", "j"]];
function check(){
    for(let i = 0; i < 3; i++){
        let cntX = 0;
        let cntO = 0; 
        for(let j = 0; j < 3; j++){
            if(cells[i][j] === "X"){
                cntX += 1; 
            } 
            if(cells[i][j] === "O"){
                cntO +=1; 
                console.log(cells[i][j]);
            }
        }
        if(cntX === 3){
            winner.innerHTML = "Winner: Player 1";
        }
        if(cntO === 3){
            winner.innerHTML = "Winner: Player 2";
        }
    }

    for(let i = 0; i < 3; i++){
        let cntX = 0;
        let cntO = 0; 
        for(let j = 0; j < 3; j++){
            if(cells[j][i] === "X"){
                cntX += 1; 
            }else if(cells[j][i] === "O"){
                cntO +=1; 
            }
        }
        if(cntX === 3){
            winner.innerHTML = "Winner: Player 1";
        }else if(cntO === 3){
            winner.innerHTML = "Winner: Player 2";
        }
    }

        let cntX = 0;
        let cntO = 0; 
        for(let i = 0; i < 3; i++){
            for(let j = 2; j >= 0; j--){
                if(cells[i][j] === "X"){
                    cntX += 1; 
                }else if(cells[i][j] === "O"){
                    cntO +=1; 
                }
            }
        }
        if(cntX === 3){
            winner.innerHTML = "Winner: Player 1";
        }else if(cntO === 3){
            winner.innerHTML = "Winner: Player 2";
        }

        cntX = 0;
        cntO = 0; 
        for(let j = 0; j < 3; j++){
            if(cells[j][j] === "X"){
                cntX += 1; 
            }else if(cells[j][j] === "O"){
                cntO +=1; 
            }
        }
        if(cntX === 3){
            winner.innerHTML = "Winner: Player 1";
        }else if(cntO === 3){
            winner.innerHTML = "Winner: Player 2";
        }
}


box1.addEventListener("click", ()=>{
    if(player1){
        box1Text.innerHTML = "X";
        box1Text.style.visibility = "visible";
        cells[0][0] = "X";
        player1 = false; 
        check();
    }else{
        box1Text.innerHTML = "O";
        cells[0][0] = "O";
        box1Text.style.visibility = "visible";
        player1 = true; 
        check();
    }
});

box2.addEventListener("click", ()=>{
    if(player1){
        box2Text.innerHTML = "X";
        cells[0][1] = "X";
        box2Text.style.visibility = "visible";
        player1 = false; 
        check();
    }else{
        box2Text.innerHTML = "O";
        cells[0][1] = "O";
        box2Text.style.visibility = "visible";
        player1 = true; 
        check();
    }
});

box3.addEventListener("click", ()=>{
    if(player1){
        box3Text.innerHTML = "X";
        cells[0][2] = "X";
        box3Text.style.visibility = "visible";
        player1 = false; 
        check();
    }else{
        box3Text.innerHTML = "O";
        cells[0][2] = "O";
        box3Text.style.visibility = "visible";
        player1 = true; 
        check();
    }
});

box4.addEventListener("click", ()=>{
    if(player1){
        box4Text.innerHTML = "X";
        cells[1][0]= "X";
        box4Text.style.visibility = "visible";
        player1 = false; 
        check();
    }else{
        box4Text.innerHTML = "O";
        cells[1][0] = "O";
        box4Text.style.visibility = "visible";
        player1 = true; 
        check();
    }
});

box5.addEventListener("click", ()=>{
    if(player1){
        box5Text.innerHTML = "X";
        cells[1][1] = "X";
        box5Text.style.visibility = "visible";
        player1 = false; 
        check();
    }else{
        box5Text.innerHTML = "O";
        cells[1][1] = "O";
        box5Text.style.visibility = "visible";
        player1 = true; 
        check();
    }
});

box6.addEventListener("click", ()=>{
    if(player1){
        box6Text.innerHTML = "X";
        cells[1][2] = "X";
        box6Text.style.visibility = "visible";
        player1 = false; 
        check();
    }else{
        box6Text.innerHTML = "O";
        cells[1][2] = "O";
        box6Text.style.visibility = "visible";
        player1 = true; 
        check();
    }
});

box7.addEventListener("click", ()=>{
    if(player1){
        box7Text.innerHTML = "X";
        cells[2][0]= "X";
        box7Text.style.visibility = "visible";
        player1 = false; 
        check();
    }else{
        box7Text.innerHTML = "O";
        cells[2][0] = "O";
        box7Text.style.visibility = "visible";
        player1 = true; 
        check();
    }
});

box8.addEventListener("click", ()=>{
    if(player1){
        box8Text.innerHTML = "X";
        cells[2][1] = "X";
        box8Text.style.visibility = "visible";
        player1 = false; 
        check();
    }else{
        box8Text.innerHTML = "O";
        box8Text.style.visibility = "visible";
        player1 = true; 
        cells[2][1] = "O";
        check();
    }
});

box9.addEventListener("click", ()=>{
    if(player1){
        box9Text.innerHTML = "X";
        cells[2][2] = "X";
        box9Text.style.visibility = "visible";
        player1 = false; 
        check();
    }else{
        box9Text.innerHTML = "O";
        cells[2][2] = "O";
        box9Text.style.visibility = "visible";
        player1 = true; 
        check();
    }
});

